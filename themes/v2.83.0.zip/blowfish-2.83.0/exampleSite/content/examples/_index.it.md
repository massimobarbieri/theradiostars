---
title: "Showcase"
description: "See what's possible with Blowfish."

showLikes: true
showViews: true

cascade:
  showEdit: false
  showReadingTime: false
  showSummary: false
  showLikes: false
  showViews: false
---

{{< lead >}}
See what's possible with Blowfish.
{{< /lead >}}

This section contains links to example templates and pages created using Blowfish to get you inspired.

---
