---
                title: "Beauty Formulation"
                tags: [Company site]
                externalUrl: "https://www.beautyformulation.com/"
                weight: 731
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
