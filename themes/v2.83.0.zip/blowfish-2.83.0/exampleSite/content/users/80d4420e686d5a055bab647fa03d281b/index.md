---
                title: "talkdimsum.com"
                tags: [App site]
                externalUrl: "https://talkdimsum.com/"
                weight: 271
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
