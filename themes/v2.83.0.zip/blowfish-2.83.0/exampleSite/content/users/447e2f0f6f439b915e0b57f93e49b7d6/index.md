---
                title: "Laterre Dev"
                tags: [Personal site,Technology Blog,Software Developer,Portfolio Site]
                externalUrl: "https://laterre.dev/"
                weight: 951
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
